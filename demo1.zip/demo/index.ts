import express from 'express';
const app = express();
app.get('/', (req, res) => {
  res.send('Hello World !!');
});
app.listen(3000, err => {
  if (err) {
    return console.error(err);
  }
  return console.log('server is listening on 3000');
});

