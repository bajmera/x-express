import express from 'express';
import mongoose from 'mongoose';

const empSchema = new mongoose.Schema(
        {
          empno: {
            type: Number,
            unique: true,
            required: true,
          },
          ename: {
              type: String,
              unique: false,
              required: true,
            },
          salary: {
              type: Number,
              unique: false,
              required: false,
            },
        },
        { timestamps: true },
      );

const EmpModel = mongoose.model("vaiemp",empSchema);

const app = express();
app.use(express.urlencoded({ extended: true })) 
app.use(express.json())

app.get('/', (req, res) => {
    res.send('Hello World from GET !!');
});
/* Path Variables */
app.get('/hello/:nm', (req, res) => {
    res.send('Hello with ' + req.params.nm );
});
app.get('/add/:n1/:n2', (req, res) => {
    let sum = +req.params.n1 + +req.params.n2;
    res.send('Hello with ' + sum );
});
/* Query Params */
app.get('/emp', async (req, res) => {
    let url ="mongodb+srv://testuser:testuser@xpanxioncluster.m7uzk.mongodb.net/mydb";
    mongoose.connect(url);
    await EmpModel.find(
        (err,arr)=>{
            if (err== null)
                res.send(arr);
            else  {  
                res.status(404).send("Problem")
                console.log(err)
            }
        }
    )
    mongoose.disconnect()
    
});
app.post('/emp', async (req, res) => {
    let url ="mongodb+srv://testuser:testuser@xpanxioncluster.m7uzk.mongodb.net/mydb";
    mongoose.connect(url);
    var empobj = new EmpModel(
        {"empno":req.body.empno,  
     "ename":req.body.ename,
     "salary": req.body.salary} );
    console.log(empobj)
    await empobj.save();
    mongoose.disconnect()
    console.log(empobj)
    res.send("POST Hello with " + empobj);
});

app.post('/', (req, res) => {
    res.send('Hello World from POST !!');
});

app.listen(3000, err => {
    if (err) {
        return console.error(err);
    }
    return console.log('server is listening on 3000');
});

